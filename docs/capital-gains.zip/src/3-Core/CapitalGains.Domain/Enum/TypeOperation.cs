namespace CapitalGains.domain.stocks.enums;

public enum TypeOperation
{
    buy = 0,
    sell = 1,
    valuenull = -1
}
